package com.phrms.camera

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.*
import android.hardware.camera2.params.ColorSpaceTransform
import android.hardware.camera2.params.MeteringRectangle
import android.hardware.camera2.params.RggbChannelVector
import android.hardware.camera2.params.TonemapCurve
import android.hardware.display.DisplayManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.ImageReader
import android.media.MediaCodecList
import android.media.MediaRecorder
import android.net.Uri
import android.os.*
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.text.InputType
import android.util.Log
import android.util.Range
import android.util.Size
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.*

class MainActivity : Activity(), SensorEventListener {
    private val tag = "PHIRMS"
    private val cyan = 0xFF3CC8E8.toInt()
    private class Lens(val id: String, val factor: Float)
    private class LensBtn(val label: String, val id: String, val zoom: Float, val factor: Float)
    private class MediaItem(val uri: Uri, val name: String, val mime: String, val size: Long)

    private val wbNames = listOf("DAY", "INC", "FLUOR", "CLOUD", "SHADE")
    private val wbModesAll = listOf(CameraMetadata.CONTROL_AWB_MODE_DAYLIGHT, CameraMetadata.CONTROL_AWB_MODE_INCANDESCENT,
        CameraMetadata.CONTROL_AWB_MODE_FLUORESCENT, CameraMetadata.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT, CameraMetadata.CONTROL_AWB_MODE_SHADE)
    private val sqVals = floatArrayOf(1f, 1.33f, 1.55f, 2f)

    private lateinit var cm: CameraManager
    private lateinit var frame: AspectFrame
    private lateinit var tv: TextureView
    private lateinit var overlay: OverlayView
    private lateinit var analyzer: Analyzer
    private lateinit var quick: LinearLayout
    private lateinit var hudScroll: HorizontalScrollView
    private lateinit var recView: ShutterView
    private lateinit var iconBox: View
    private lateinit var mediaView: FrameLayout
    private lateinit var mediaList: ListView
    private lateinit var dimView: View
    private val chipVal = HashMap<String, TextView>()
    private val chipBox = HashMap<String, LinearLayout>()
    private val tabs = mutableListOf<LinearLayout>()

    private val audioMeter = AudioMeter { l, r -> overlay.audioL = l; overlay.audioR = r }
    private val audioManager by lazy { getSystemService(AUDIO_SERVICE) as AudioManager }
    private val sensorManager by lazy { getSystemService(SENSOR_SERVICE) as SensorManager }
    private val prefs by lazy { getSharedPreferences("phirms", MODE_PRIVATE) }
    private val thumbExec = Executors.newFixedThreadPool(2)
    private val ui = Handler(Looper.getMainLooper())
    private var bgThread: HandlerThread? = null
    private var bg: Handler? = null
    private val openLock = Semaphore(1)
    private val lockHeld = AtomicBoolean(false)

    private var camera: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var chars: CameraCharacteristics? = null
    private var builder: CaptureRequest.Builder? = null
    private var jpegReader: ImageReader? = null
    private var camId: String? = null

    // user settings
    private var facing = CameraCharacteristics.LENS_FACING_BACK
    private var lensId: String? = null
    private var fps = 30
    private var resH = 2160
    private var hevc = false
    private var mbps = 40
    private var tl = 1
    private var manualExp = false
    private var angleMode = false
    private var flicker = 0
    private var iso = 100
    private var expNs = 20_000_000L
    private var apIdx = 0
    private var wbKind = 0
    private var wbPreset = 0
    private var kelvin = 5600
    private var tint = 0
    private var manualFocus = false
    private var focusP = 0f
    private var afLock = false
    private var aeLock = false
    private var evIdx = 0
    private var zoom = 1f
    private var lookIdx = 0
    private var stabIdx = 0
    private var rackSec = 2
    private val marks = floatArrayOf(-1f, -1f, -1f)
    private var sqIdx = 0
    private var flip = false
    private var jpegQ = 95
    private var portraitOn = false
    private var depthP = 0.6f
    private var volKeys = true
    private var micId = -1
    private var micDir = 0
    private var micCh = 2
    private var safTree: String? = null
    private var slProject = "PHIRMS"; private var slReel = "1"; private var slScene = "1"; private var slTake = 1
    private var slGood = false; private var slExt = false; private var slNight = false
    private var regions: Array<MeteringRectangle>? = null

    // capabilities of the open camera
    private var lenses = listOf<Lens>()
    private var lensBtns = listOf<LensBtn>()
    private var videoSizes = listOf<Size>()
    private var videoSize = Size(1920, 1080)
    private var previewSize = Size(1920, 1080)
    private var photoSize = Size(1920, 1080)
    private var fpsList = listOf(30)
    private var manualOk = false
    private var isoRange = Range(100, 100)
    private var expRange = Range(1_000_000L, 1_000_000L)
    private var minFocus = 0f
    private var evRange = Range(0, 0)
    private var evStep = 0f
    private var zoomMin = 1f
    private var zoomMax = 1f
    private var useRatio = false
    private var maxAf = 0
    private var maxAe = 0
    private var apertures = floatArrayOf()
    private var awbAvail = listOf<Int>()
    private var wbManualOk = false
    private var stabOpts = listOf("OFF")
    private var looks = listOf("OFF")
    private val hevcOk by lazy { encoderExists("video/hevc") }

    // white-balance calibration (manual Kelvin)
    @Volatile private var lastGains: RggbChannelVector? = null
    @Volatile private var lastTransform: ColorSpaceTransform? = null
    private var calDay: FloatArray? = null
    private var calInc: FloatArray? = null
    private var calTransform: ColorSpaceTransform? = null
    private var calOk = false
    private var calBusy = false
    @Volatile private var calMode: Int? = null

    // live values reported by the camera
    @Volatile private var lastIso: Int? = null
    @Volatile private var lastExp: Long? = null
    @Volatile private var lastAperture: Float? = null

    // recording state
    @Volatile private var recording = false
    @Volatile private var pendingPortrait = false
    private var recorder: MediaRecorder? = null
    private var recUri: Uri? = null
    private var recIsSaf = false
    private var recPfd: ParcelFileDescriptor? = null
    private var recStart = 0L
    private var lastUri: Uri? = null
    private var lastMime = "video/mp4"
    private var tickN = 0
    private var scaled = false
    private var panelName: String? = null
    private var freePct = "--"

    private val frameNs get() = (1e9 / fps).toLong()
    private fun hasPerm(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun toast(s: String) = runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun cam(block: () -> Unit) {
        bg?.post { try { block() } catch (e: Exception) { Log.e(tag, "camera op failed", e); toast("Error: ${e.message}") } }
    }
    @Suppress("DEPRECATION")
    private fun rotation() = windowManager.defaultDisplay.rotation
    private fun isLand() = rotation().let { it == Surface.ROTATION_90 || it == Surface.ROTATION_270 }
    private fun shutMin() = max(expRange.lower, 125_000L)
    private fun shutMax() = max(shutMin() + 1, min(frameNs, expRange.upper))
    private fun fl(w: Int, h: Int, g: Int = Gravity.NO_GRAVITY) = FrameLayout.LayoutParams(w, h, g)

    // ───────────────────────── lifecycle ─────────────────────────
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        cm = getSystemService(CAMERA_SERVICE) as CameraManager
        loadPrefs()
        buildUi()
        if (!hasPerm(Manifest.permission.CAMERA) || !hasPerm(Manifest.permission.RECORD_AUDIO))
            requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), 1)
    }

    override fun onResume() {
        super.onResume()
        bgThread = HandlerThread("phirms-cam").also { it.start() }
        bg = Handler(bgThread!!.looper)
        if (hasPerm(Manifest.permission.CAMERA) && tv.isAvailable) cam { openCamera() }
        if (hasPerm(Manifest.permission.RECORD_AUDIO)) audioMeter.start()
        updateSensor()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(displayListener, null)
        ui.post(ticker)
    }

    override fun onPause() {
        ui.removeCallbacks(ticker); ui.removeCallbacks(rackRun)
        savePrefs()
        sensorManager.unregisterListener(this)
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(displayListener)
        audioMeter.stop()
        bg?.post { try { stopRecording(false); closeCamera() } catch (e: Exception) { Log.e(tag, "pause", e) } }
        bgThread?.quitSafely()
        try { bgThread?.join(4000) } catch (e: Exception) {}
        bgThread = null; bg = null
        super.onPause()
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (volKeys && (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) && event?.repeatCount == 0) { onRecord(); return true }
        return super.onKeyDown(keyCode, event)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 42 && res == RESULT_OK) {
            val u = data?.data ?: return
            try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (e: Exception) {}
            safTree = u.toString(); savePrefs(); toast("Recording to the chosen folder")
        }
    }

    // level indicator
    private fun updateSensor() {
        sensorManager.unregisterListener(this)
        if (overlay.showLevel) sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
    }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    override fun onSensorChanged(e: SensorEvent) {
        val ax = e.values[0]; val ay = e.values[1]
        val (sx, sy) = when (rotation()) {
            Surface.ROTATION_90 -> (-ay) to ax; Surface.ROTATION_180 -> (-ax) to (-ay); Surface.ROTATION_270 -> ay to (-ax); else -> ax to ay
        }
        val t = Math.toDegrees(atan2(sx.toDouble(), sy.toDouble())).toFloat()
        overlay.tilt = overlay.tilt * 0.8f + t * 0.2f
    }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(id: Int) {}
        override fun onDisplayRemoved(id: Int) {}
        override fun onDisplayChanged(id: Int) { runOnUiThread { applyTransform() } }
    }

    private val ticker = object : Runnable {
        override fun run() {
            tickN++
            if (recording) { val a = try { (recorder?.maxAmplitude ?: 0) / 32768f } catch (e: Exception) { 0f }; overlay.audioL = a; overlay.audioR = a }
            if (tickN % 2 == 0) analyzer.tick()
            if (tickN % 10 == 0) checkLimits()
            if (tickN % 3 == 0) hudUpdate()
            overlay.lockText = if (afLock) "AF / AE LOCK" else ""
            overlay.invalidate()
            ui.postDelayed(this, 100)
        }
    }

    private fun checkLimits() {
        val free = freeBytes()
        val thermal = (getSystemService(POWER_SERVICE) as PowerManager).currentThermalStatus
        try { val sf = StatFs(Environment.getExternalStorageDirectory().path); freePct = "${sf.availableBytes * 100 / max(1L, sf.totalBytes)}%" } catch (e: Exception) {}
        if (recording && !recIsSaf && free < 150L * 1024 * 1024) { toast("Storage almost full – stopping"); cam { stopRecording() } }
        if (recording && thermal >= PowerManager.THERMAL_STATUS_CRITICAL) { toast("Device too hot – stopping"); cam { stopRecording() } }
        else if (thermal >= PowerManager.THERMAL_STATUS_SEVERE && tickN % 100 == 0) toast("Device is very warm")
    }

    @Suppress("DEPRECATION")
    private fun freeBytes() = StatFs(Environment.getExternalStorageDirectory().path).availableBytes

    // ───────────────────────── prefs ─────────────────────────
    private fun loadPrefs() = prefs.run {
        fps = getInt("fps", 30); resH = getInt("resH", 2160); hevc = getBoolean("hevc", false); mbps = getInt("mbps", 40); tl = getInt("tl", 1)
        manualExp = getBoolean("mexp", false); angleMode = getBoolean("angle", false); flicker = getInt("flicker", 0)
        wbKind = getInt("wbKind", 0); wbPreset = getInt("wbPreset", 0); kelvin = getInt("kelvin", 5600); tint = getInt("tint", 0)
        manualFocus = getBoolean("mf", false); stabIdx = getInt("stab", 0); lookIdx = getInt("look", 0)
        facing = getInt("facing", CameraCharacteristics.LENS_FACING_BACK); lensId = getString("lensId", null)
        sqIdx = getInt("sq", 0); flip = getBoolean("flip", false); jpegQ = getInt("jq", 95); portraitOn = getBoolean("portrait", false)
        depthP = getFloat("depth", 0.6f); volKeys = getBoolean("vol", true); micId = getInt("micId", -1); micDir = getInt("micDir", 0); micCh = getInt("micCh", 2)
        safTree = getString("saf", null); rackSec = getInt("rack", 2)
        slProject = getString("slP", "PHIRMS") ?: "PHIRMS"; slReel = getString("slR", "1") ?: "1"; slScene = getString("slS", "1") ?: "1"
        slTake = getInt("slT", 1); slGood = getBoolean("slG", false); slExt = getBoolean("slE", false); slNight = getBoolean("slN", false)
    }

    private fun savePrefs() = prefs.edit().apply {
        putInt("fps", fps); putInt("resH", resH); putBoolean("hevc", hevc); putInt("mbps", mbps); putInt("tl", tl)
        putBoolean("mexp", manualExp); putBoolean("angle", angleMode); putInt("flicker", flicker)
        putInt("wbKind", wbKind); putInt("wbPreset", wbPreset); putInt("kelvin", kelvin); putInt("tint", tint)
        putBoolean("mf", manualFocus); putInt("stab", stabIdx); putInt("look", lookIdx)
        putInt("facing", facing); putString("lensId", lensId); putInt("sq", sqIdx); putBoolean("flip", flip); putInt("jq", jpegQ)
        putBoolean("portrait", portraitOn); putFloat("depth", depthP); putBoolean("vol", volKeys); putInt("micId", micId); putInt("micDir", micDir)
        putInt("micCh", micCh); putString("saf", safTree); putInt("rack", rackSec)
        putString("slP", slProject); putString("slR", slReel); putString("slS", slScene); putInt("slT", slTake)
        putBoolean("slG", slGood); putBoolean("slE", slExt); putBoolean("slN", slNight)
        putBoolean("hist", overlay.showHist); putBoolean("audio", overlay.showAudio); putBoolean("level", overlay.showLevel)
        putInt("grid", overlay.grid); putBoolean("cross", overlay.cross); putBoolean("dot", overlay.dot); putInt("guide", overlay.guideIdx)
        putBoolean("zebra", analyzer.zebra); putInt("zebraLvl", analyzer.zebraLevel); putBoolean("peak", analyzer.peak)
        putInt("peakCol", analyzer.peakColor); putBoolean("false", analyzer.falseColor)
    }.apply()

    // ───────────────────────── UI building blocks ─────────────────────────
    private fun tb(text: String, sel: Boolean = false, enabled: Boolean = true, onClick: () -> Unit): TextView = TextView(this).apply {
        this.text = text; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setTextColor(if (sel) Color.BLACK else Color.WHITE)
        background = GradientDrawable().apply { cornerRadius = dp(6).toFloat(); setColor(if (sel) cyan else 0x44FFFFFF) }
        setPadding(dp(10), dp(6), dp(10), dp(6)); alpha = if (enabled) 1f else 0.4f
        setOnClickListener { if (enabled) onClick() }
    }

    private fun hrow(vararg v: View): HorizontalScrollView {
        val l = LinearLayout(this).apply { setPadding(dp(8), dp(3), dp(8), dp(3)) }
        v.forEach { l.addView(it, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(6) }) }
        return HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(l) }
    }

    private fun sRow(title: String, p0: Int, fmt: (Int) -> String, on: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), 0, dp(8), 0) }
        val t = TextView(this).apply { text = "$title  ${fmt(p0)}"; setTextColor(Color.WHITE); textSize = 12f; typeface = Typeface.MONOSPACE; minWidth = dp(150) }
        val s = SeekBar(this).apply { max = 1000; progress = p0.coerceIn(0, 1000) }
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) { if (fromUser) { on(p); t.text = "$title  ${fmt(p)}" } }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
        row.addView(t); row.addView(s, LinearLayout.LayoutParams(0, -2, 1f))
        return row
    }

    private fun lp(v: Double, a: Double, b: Double) = if (b > a) ((ln(v) - ln(a)) / (ln(b) - ln(a)) * 1000).toInt().coerceIn(0, 1000) else 0
    private fun unlp(p: Int, a: Double, b: Double) = exp(ln(a) + (ln(b) - ln(a)) * p / 1000.0)

    private fun chip(key: String, label: String, panel: String?): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(8), dp(3), dp(8), dp(3)) }
        box.addView(TextView(this).apply { text = label; textSize = 9f; setTextColor(0xFF9AA0A6.toInt()); gravity = Gravity.CENTER })
        val v = TextView(this).apply { textSize = 15f; typeface = Typeface.MONOSPACE; setTextColor(Color.WHITE); gravity = Gravity.CENTER; text = "–" }
        box.addView(v); chipVal[key] = v; chipBox[key] = box
        if (panel != null) box.setOnClickListener { openPanel(panel) }
        return box
    }

    private fun ib(kind: Int, onClick: () -> Unit) = IconView(this, kind).apply { setOnClickListener { onClick() } }

    private fun tab(kind: Int, label: String, onClick: () -> Unit): LinearLayout {
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(4), dp(6), dp(4), dp(6)); setOnClickListener { onClick() } }
        l.addView(IconView(this, when (label) { "Camera" -> 3; "Media" -> 4; else -> 0 }), LinearLayout.LayoutParams(dp(30), dp(30)))
        l.addView(TextView(this).apply { text = label; textSize = 10f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
        tabs.add(l)
        return l
    }

    private fun selectTab(i: Int) {
        for (k in tabs.indices) tabs[k].setBackgroundColor(if (k == i) 0x553CC8E8 else Color.TRANSPARENT)
    }

    private fun buildUi() {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        frame = AspectFrame(this); tv = TextureView(this); overlay = OverlayView(this)
        frame.addView(tv, fl(-1, -1)); frame.addView(overlay, fl(-1, -1))
        analyzer = Analyzer(tv, overlay)
        prefs.run {
            overlay.showHist = getBoolean("hist", true); overlay.showAudio = getBoolean("audio", true); overlay.showLevel = getBoolean("level", false)
            overlay.grid = getInt("grid", 1); overlay.cross = getBoolean("cross", false); overlay.dot = getBoolean("dot", false); overlay.guideIdx = getInt("guide", 0)
            analyzer.zebra = getBoolean("zebra", false); analyzer.zebraLevel = getInt("zebraLvl", 95); analyzer.peak = getBoolean("peak", false)
            analyzer.peakColor = getInt("peakCol", 0); analyzer.falseColor = getBoolean("false", false)
        }
        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                applyTransform(); if (hasPerm(Manifest.permission.CAMERA)) cam { openCamera() }
            }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) { applyTransform() }
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        setupTouch()

        // HUD row (tap a value to open its quick controls)
        val hudRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        hudRow.addView(chip("LENS", "LENS", "LENS")); hudRow.addView(chip("FPS", "FPS", "FPS")); hudRow.addView(chip("SHUTTER", "SHUTTER", "SHUTTER"))
        hudRow.addView(chip("IRIS", "IRIS", "IRIS")); hudRow.addView(chip("TC", "TIMECODE", null)); hudRow.addView(chip("ISO", "ISO", "ISO"))
        hudRow.addView(chip("WB", "WB", "WB")); hudRow.addView(chip("TINT", "TINT", "WB")); hudRow.addView(chip("FORMAT", "FORMAT", "RES"))
        hudRow.addView(chip("STORE", "STORAGE", null))
        hudScroll = HorizontalScrollView(this).apply { setBackgroundColor(0x66000000); isHorizontalScrollBarEnabled = false; addView(hudRow) }
        quick = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xDD000000.toInt()); setPadding(0, dp(4), 0, dp(4)); visibility = View.GONE }

        mediaList = ListView(this).apply { setBackgroundColor(Color.BLACK); divider = null }
        mediaList.setOnItemClickListener { _, _, pos, _ ->
            (mediaList.adapter?.getItem(pos) as? MediaItem)?.let { m ->
                try { startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(m.uri, m.mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) } catch (e: Exception) { toast("No app found to open it") }
            }
        }
        mediaView = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); visibility = View.GONE; addView(mediaList, fl(-1, -1)) }

        val pv = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        pv.addView(frame, fl(-1, -1, Gravity.CENTER))
        pv.addView(hudScroll, fl(-1, -2, Gravity.TOP))
        pv.addView(quick, fl(-1, -2, Gravity.BOTTOM))
        pv.addView(mediaView, fl(-1, -1))

        recView = ShutterView(this).apply { setOnClickListener { onRecord() } }
        val bMon = ib(5) { openPanel("MONITOR") }; val bFoc = ib(6) { openPanel("FOCUS") }; val bExpo = ib(7) { openPanel("EXPOSURE") }
        val bPhoto = ib(3) { takePhoto() }; val bSlate = ib(8) { showSlate() }
        val tCam = tab(3, "Camera") { showMedia(false) }; val tMed = tab(4, "Media") { showMedia(true) }; val tSet = tab(0, "Settings") { showSettings() }

        val main: View
        if (land) {
            val icons = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(Color.BLACK) }
            icons.addView(bMon, LinearLayout.LayoutParams(dp(44), dp(40))); icons.addView(bFoc, LinearLayout.LayoutParams(dp(44), dp(40)))
            icons.addView(bExpo, LinearLayout.LayoutParams(dp(44), dp(40)))
            icons.addView(recView, LinearLayout.LayoutParams(dp(64), dp(64)).apply { topMargin = dp(8); bottomMargin = dp(8) })
            icons.addView(bPhoto, LinearLayout.LayoutParams(dp(44), dp(40))); icons.addView(bSlate, LinearLayout.LayoutParams(dp(44), dp(40)))
            val tabCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(0xFF08080C.toInt()) }
            tabCol.addView(tCam); tabCol.addView(tMed); tabCol.addView(tSet)
            val root = LinearLayout(this).apply { setBackgroundColor(Color.BLACK) }
            root.addView(pv, LinearLayout.LayoutParams(0, -1, 1f))
            root.addView(icons, LinearLayout.LayoutParams(dp(70), -1))
            root.addView(tabCol, LinearLayout.LayoutParams(dp(76), -1))
            iconBox = icons; main = root
        } else {
            val icons = LinearLayout(this).apply { gravity = Gravity.CENTER; setBackgroundColor(Color.BLACK) }
            icons.addView(bMon, LinearLayout.LayoutParams(0, dp(44), 1f)); icons.addView(bFoc, LinearLayout.LayoutParams(0, dp(44), 1f))
            icons.addView(recView, LinearLayout.LayoutParams(dp(72), dp(72)))
            icons.addView(bExpo, LinearLayout.LayoutParams(0, dp(44), 1f)); icons.addView(bPhoto, LinearLayout.LayoutParams(0, dp(44), 1f))
            icons.addView(bSlate, LinearLayout.LayoutParams(0, dp(44), 1f))
            val tabRow = LinearLayout(this).apply { gravity = Gravity.CENTER; setBackgroundColor(0xFF08080C.toInt()) }
            tabRow.addView(tCam, LinearLayout.LayoutParams(0, -2, 1f)); tabRow.addView(tMed, LinearLayout.LayoutParams(0, -2, 1f)); tabRow.addView(tSet, LinearLayout.LayoutParams(0, -2, 1f))
            val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
            root.addView(pv, LinearLayout.LayoutParams(-1, 0, 1f))
            root.addView(icons, LinearLayout.LayoutParams(-1, dp(84)))
            root.addView(tabRow, LinearLayout.LayoutParams(-1, dp(62)))
            iconBox = icons; main = root
        }
        dimView = View(this).apply { setBackgroundColor(Color.BLACK); visibility = View.GONE; setOnClickListener { setDim(false) } }
        val top = FrameLayout(this)
        top.addView(main, fl(-1, -1)); top.addView(dimView, fl(-1, -1))
        setContentView(top)
        selectTab(0)
        hudUpdate()
    }

    private fun showMedia(on: Boolean) {
        mediaView.visibility = if (on) View.VISIBLE else View.GONE
        iconBox.visibility = if (on) View.INVISIBLE else View.VISIBLE
        selectTab(if (on) 1 else 0)
        if (on) loadMedia()
    }

    private fun loadMedia() = Thread {
        val items = mutableListOf<MediaItem>()
        try {
            val proj = arrayOf(MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.DISPLAY_NAME, MediaStore.Files.FileColumns.MIME_TYPE, MediaStore.Files.FileColumns.SIZE)
            contentResolver.query(MediaStore.Files.getContentUri("external"), proj, "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?", arrayOf("%PHIRMS%"),
                "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
                while (c.moveToNext() && items.size < 80) {
                    val mime = c.getString(2) ?: ""
                    val base = if (mime.startsWith("video")) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                    items.add(MediaItem(ContentUris.withAppendedId(base, c.getLong(0)), c.getString(1) ?: "?", mime, c.getLong(3)))
                }
            }
        } catch (e: Exception) { Log.e(tag, "media", e) }
        runOnUiThread {
            mediaList.adapter = object : BaseAdapter() {
                override fun getCount() = items.size
                override fun getItem(i: Int): Any = items[i]
                override fun getItemId(i: Int) = i.toLong()
                override fun getView(i: Int, cv: View?, parent: ViewGroup?): View {
                    val m = items[i]
                    val row = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(6), dp(10), dp(6)) }
                    val img = ImageView(this@MainActivity).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(0xFF1C1C1E.toInt()); tag = m.uri }
                    row.addView(img, LinearLayout.LayoutParams(dp(84), dp(56)))
                    row.addView(TextView(this@MainActivity).apply {
                        text = m.name + "\n" + (if (m.mime.startsWith("video")) "video  " else "photo  ") + String.format(Locale.US, "%.1f MB", m.size / 1048576.0)
                        setTextColor(Color.WHITE); textSize = 12f; setPadding(dp(12), 0, 0, 0)
                    })
                    thumbExec.execute {
                        try { val b = contentResolver.loadThumbnail(m.uri, Size(240, 160), null); runOnUiThread { if (img.tag == m.uri) img.setImageBitmap(b) } } catch (e: Exception) {}
                    }
                    return row
                }
            }
            if (items.isEmpty()) toast("No PHIRMS files yet")
        }
    }.start()

    private fun hudUpdate() {
        fun set(k: String, v: String) { chipVal[k]?.text = v }
        val eqf = chars?.let { focalEq(it) } ?: 26f
        set("LENS", "${(eqf * zoom).roundToInt()}mm")
        set("FPS", if (tl > 1) "$fps×TL$tl" else "$fps")
        val e = if (manualExp) expNs.coerceIn(shutMin(), shutMax()) else (lastExp ?: expNs)
        set("SHUTTER", if (angleMode) "${(e * 360.0 / frameNs).roundToInt()}°" else "1/${(1e9 / max(1L, e)).roundToInt()}")
        set("IRIS", lastAperture?.let { String.format(Locale.US, "f%.1f", it) } ?: "–")
        set("ISO", if (manualExp) "$iso" else (lastIso?.toString() ?: "–"))
        set("WB", when (wbKind) { 0 -> "AUTO"; 1 -> wbNames[wbPreset.coerceIn(0, 4)]; else -> "${kelvin}K" })
        set("TINT", if (wbKind == 2) "$tint" else "–")
        val t = if (recording) (SystemClock.elapsedRealtime() - recStart) / 1000 else 0
        set("TC", String.format(Locale.US, "%02d:%02d:%02d", t / 3600, t / 60 % 60, t % 60))
        chipVal["TC"]?.setTextColor(if (recording) 0xFFFF453A.toInt() else Color.WHITE)
        set("FORMAT", (if (resH >= 2160) "4K" else "${resH}p") + if (hevc) " H265" else " H264")
        set("STORE", freePct)
        val cp = mapOf("LENS" to "LENS", "FPS" to "FPS", "SHUTTER" to "SHUTTER", "IRIS" to "IRIS", "ISO" to "ISO", "WB" to "WB", "TINT" to "WB", "FORMAT" to "RES")
        for ((k, box) in chipBox) box.setBackgroundColor(if (cp[k] != null && cp[k] == panelName) 0xAA1E88A8.toInt() else Color.TRANSPARENT)
    }

    private fun setHud(on: Boolean) {
        overlay.hudOn = on
        hudScroll.visibility = if (on) View.VISIBLE else View.GONE
        quick.visibility = if (on && panelName != null) View.VISIBLE else View.GONE
        overlay.invalidate()
    }

    private fun setDim(on: Boolean) {
        dimView.visibility = if (on) View.VISIBLE else View.GONE
        val a = window.attributes
        a.screenBrightness = if (on) 0.01f else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        window.attributes = a
    }

    private fun setupTouch() {
        val sd = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                zoom = (zoom * d.scaleFactor).coerceIn(zoomMin, zoomMax); scaled = true; refresh(); return true
            }
        })
        var x0 = 0f; var y0 = 0f; var moved = false; var longFired = false
        val longRun = Runnable {
            longFired = true
            tapFocus(x0 / max(1, frame.width), y0 / max(1, frame.height))
            afLock = true; aeLock = !manualExp; refresh()
        }
        frame.setOnTouchListener { v, e ->
            sd.onTouchEvent(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { scaled = false; x0 = e.x; y0 = e.y; moved = false; longFired = false; ui.postDelayed(longRun, 700) }
                MotionEvent.ACTION_MOVE -> if (abs(e.x - x0) > dp(12) || abs(e.y - y0) > dp(12)) { moved = true; ui.removeCallbacks(longRun) }
                MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_CANCEL -> ui.removeCallbacks(longRun)
                MotionEvent.ACTION_UP -> {
                    ui.removeCallbacks(longRun)
                    if (!scaled && !longFired && e.pointerCount == 1) {
                        val dx = e.x - x0; val dy = e.y - y0
                        if (abs(dy) > dp(80) && abs(dy) > 2 * abs(dx)) setHud(!overlay.hudOn)
                        else if (dx > dp(80) && abs(dx) > 2 * abs(dy)) { if (recording) setDim(true) }
                        else if (!moved) tapFocus(e.x / v.width, e.y / v.height)
                    }
                }
            }
            true
        }
    }

    private fun setRecUi(rec: Boolean) {
        recView.rec = rec
        requestedOrientation = if (rec) ActivityInfo.SCREEN_ORIENTATION_LOCKED else ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        if (rec) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) else { window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); setDim(false) }
        hudUpdate()
    }

    private fun setFrameAspect() {
        val sq = sqVals[sqIdx.coerceIn(0, 3)]
        val bw = if (isLand()) previewSize.width else previewSize.height
        val bh = if (isLand()) previewSize.height else previewSize.width
        frame.setAspect((bw * sq * 100).toInt(), bh * 100)
    }

    /** Same transform as Google's Camera2Basic sample: portrait needs none, landscape needs un-rotating. */
    private fun applyTransform() {
        setFrameAspect()
        tv.scaleX = if (flip) -1f else 1f
        val vw = tv.width.toFloat(); val vh = tv.height.toFloat()
        if (vw == 0f || vh == 0f) return
        val cx = vw / 2f; val cy = vh / 2f
        val m = Matrix()
        val rot = rotation()
        if (rot == Surface.ROTATION_90 || rot == Surface.ROTATION_270) {
            val buf = RectF(0f, 0f, previewSize.height.toFloat(), previewSize.width.toFloat())
            buf.offset(cx - buf.centerX(), cy - buf.centerY())
            m.setRectToRect(RectF(0f, 0f, vw, vh), buf, Matrix.ScaleToFit.FILL)
            val s = max(vh / previewSize.height, vw / previewSize.width)
            m.postScale(s, s, cx, cy)
            m.postRotate(90f * (rot - 2), cx, cy)
        } else if (rot == Surface.ROTATION_180) m.postRotate(180f, cx, cy)
        tv.setTransform(m)
    }

    // ───────────────────────── quick panels ─────────────────────────
    private fun openPanel(name: String) {
        if (panelName == name) { panelName = null; quick.removeAllViews(); quick.visibility = View.GONE; hudUpdate(); return }
        panelName = name
        quick.removeAllViews()
        quick.visibility = if (overlay.hudOn) View.VISIBLE else View.GONE
        when (name) {
            "LENS" -> panelLens(); "FPS" -> panelFps(); "SHUTTER" -> panelShutter(); "IRIS" -> panelIris(); "ISO" -> panelIso()
            "WB" -> panelWb(); "FOCUS" -> panelFocus(); "EXPOSURE" -> panelExposure(); "MONITOR" -> panelMonitor(); "RES" -> panelRes()
        }
        hudUpdate()
    }

    private fun rebuildPanel() { val n = panelName; panelName = null; if (n != null) openPanel(n) }

    private fun ensureManual() { if (!manualExp) setManualExp(true) }

    private fun setManualExp(on: Boolean) {
        if (on && !manualOk) { toast("Manual exposure is not supported by this camera"); return }
        if (on) { lastIso?.let { iso = it.coerceIn(isoRange.lower, isoRange.upper) }; lastExp?.let { expNs = snapFlicker(it) } }
        manualExp = on; if (on) aeLock = false
        refresh(); hudUpdate()
    }

    private fun snapFlicker(ns: Long): Long {
        if (flicker == 0) return ns.coerceIn(shutMin(), shutMax())
        val per = 1e9 / (2.0 * flicker)
        val k = max(1.0, (ns / per).roundToInt().toDouble())
        return (k * per).toLong().coerceIn(shutMin(), shutMax())
    }

    private fun panelIso() {
        val items = mutableListOf<View>(tb("AUTO", !manualExp) { setManualExp(false); rebuildPanel() }, tb("MANUAL", manualExp, manualOk) { setManualExp(true); rebuildPanel() })
        listOf(100, 200, 400, 800, 1600, 3200, 6400).filter { it >= isoRange.lower && it <= isoRange.upper }.forEach { v ->
            items.add(tb("$v", manualExp && iso == v) { ensureManual(); iso = v; refresh(); rebuildPanel() })
        }
        quick.addView(hrow(*items.toTypedArray()))
        val a = isoRange.lower.toDouble(); val b = isoRange.upper.toDouble()
        quick.addView(sRow("ISO", lp(iso.toDouble(), a, b), { p -> "${unlp(p, a, b).roundToInt()}" }) { p ->
            ensureManual(); iso = unlp(p, a, b).roundToInt().coerceIn(isoRange.lower, isoRange.upper); refresh(); hudUpdate()
        })
    }

    private fun panelShutter() {
        quick.addView(hrow(
            tb("AUTO", !manualExp) { setManualExp(false); rebuildPanel() }, tb("MANUAL", manualExp, manualOk) { setManualExp(true); rebuildPanel() },
            tb("SPEED", !angleMode) { angleMode = false; rebuildPanel() }, tb("ANGLE", angleMode) { angleMode = true; rebuildPanel() },
            tb("50Hz FREE", flicker == 50) { flicker = if (flicker == 50) 0 else 50; expNs = snapFlicker(expNs); refresh(); rebuildPanel() },
            tb("60Hz FREE", flicker == 60) { flicker = if (flicker == 60) 0 else 60; expNs = snapFlicker(expNs); refresh(); rebuildPanel() }))
        val a = shutMin().toDouble(); val b = shutMax().toDouble()
        val cur = expNs.toDouble().coerceIn(a, b)
        quick.addView(sRow(if (angleMode) "ANGLE" else "SHUTTER", lp(cur, a, b), { p ->
            val e = unlp(p, a, b)
            if (angleMode) String.format(Locale.US, "%.1f°", e * 360.0 / frameNs) else "1/${(1e9 / e).roundToInt()}"
        }) { p -> ensureManual(); expNs = snapFlicker(unlp(p, a, b).toLong()); refresh(); hudUpdate() })
        val items = mutableListOf<View>()
        if (angleMode) listOf(45.0, 90.0, 144.0, 172.8, 180.0, 270.0, 360.0).forEach { ang ->
            items.add(tb("${ang}°".replace(".0°", "°")) { ensureManual(); expNs = snapFlicker((ang / 360.0 * frameNs).toLong()); refresh(); rebuildPanel() })
        } else listOf(24, 25, 30, 48, 50, 60, 100, 120, 250, 500, 1000, 2000, 4000, 8000).forEach { n ->
            val ns = (1e9 / n).toLong()
            if (ns in shutMin()..shutMax()) items.add(tb("1/$n", manualExp && abs(expNs - ns) < ns / 20) { ensureManual(); expNs = snapFlicker(ns); refresh(); rebuildPanel() })
        }
        quick.addView(hrow(*items.toTypedArray()))
    }

    private fun panelIris() {
        if (apertures.size > 1) {
            quick.addView(hrow(*apertures.mapIndexed { i, f -> tb(String.format(Locale.US, "f/%.1f", f), manualExp && apIdx == i) { ensureManual(); apIdx = i; refresh(); rebuildPanel() } }.toTypedArray()))
            quick.addView(TextView(this).apply { text = "Aperture is applied in MANUAL exposure."; setTextColor(0xFFAAAAAA.toInt()); textSize = 11f; setPadding(dp(12), 0, 0, dp(4)) })
        } else quick.addView(TextView(this).apply {
            text = "Fixed aperture" + (lastAperture?.let { String.format(Locale.US, " f/%.1f", it) } ?: "") + ". This phone exposes no variable aperture to apps."
            setTextColor(Color.WHITE); textSize = 12f; setPadding(dp(12), dp(6), dp(12), dp(6))
        })
    }

    private fun panelWb() {
        val items = mutableListOf<View>(tb("AUTO", wbKind == 0) { wbKind = 0; refresh(); rebuildPanel() })
        wbNames.forEachIndexed { i, n ->
            items.add(tb(n, wbKind == 1 && wbPreset == i, wbModesAll[i] in awbAvail) { wbKind = 1; wbPreset = i; refresh(); rebuildPanel() })
        }
        items.add(tb("KELVIN", wbKind == 2, wbManualOk) { wbKind = 2; if (!calOk) calibrateWb(); refresh(); rebuildPanel() })
        quick.addView(hrow(*items.toTypedArray()))
        quick.addView(sRow("KELVIN", (kelvin - 2500) * 1000 / 7500, { p -> "${2500 + 7500 * p / 1000}K" }) { p ->
            if (wbManualOk) { kelvin = 2500 + 7500 * p / 1000; if (wbKind != 2) { wbKind = 2; if (!calOk) calibrateWb() }; refresh(); hudUpdate() }
        })
        quick.addView(sRow("TINT", (tint + 50) * 10, { p -> "${p / 10 - 50}" }) { p ->
            if (wbManualOk) { tint = p / 10 - 50; if (wbKind != 2) { wbKind = 2; if (!calOk) calibrateWb() }; refresh(); hudUpdate() }
        })
        if (!wbManualOk) quick.addView(TextView(this).apply { text = "Manual Kelvin/tint is not supported by this camera – presets only."; setTextColor(0xFFAAAAAA.toInt()); textSize = 11f; setPadding(dp(12), 0, 0, dp(4)) })
    }

    private fun panelFocus() {
        quick.addView(hrow(
            tb("AF", !manualFocus) { manualFocus = false; refresh(); rebuildPanel() },
            tb("MF", manualFocus, minFocus > 0f) { manualFocus = true; afLock = false; refresh(); rebuildPanel() },
            tb("AF LOCK", afLock) { afLock = !afLock; aeLock = afLock && !manualExp; refresh(); rebuildPanel() },
            tb("PEAK", analyzer.peak) { analyzer.peak = !analyzer.peak; rebuildPanel() },
            tb("COLOR " + listOf("RED", "GREEN", "BLUE", "WHITE", "BLACK")[analyzer.peakColor]) { analyzer.peakColor = (analyzer.peakColor + 1) % 5; analyzer.peak = true; rebuildPanel() }))
        quick.addView(sRow("FOCUS", (focusP * 1000).toInt(), { p -> String.format(Locale.US, "%.2f", p / 1000f) }) { p ->
            if (minFocus > 0f) { manualFocus = true; focusP = p / 1000f; refresh(); hudUpdate() } else toast("Manual focus not supported")
        })
        quick.addView(hrow(
            tb("MARK 1") { marks[0] = focusP; toast("Mark 1 set") }, tb("MARK 2") { marks[1] = focusP; toast("Mark 2 set") }, tb("MARK 3") { marks[2] = focusP; toast("Mark 3 set") },
            tb("GO 1", false, marks[0] >= 0f) { rack(0) }, tb("GO 2", false, marks[1] >= 0f) { rack(1) }, tb("GO 3", false, marks[2] >= 0f) { rack(2) },
            tb("SPEED ${rackSec}s") { rackSec = when (rackSec) { 1 -> 2; 2 -> 4; 4 -> 8; else -> 1 }; rebuildPanel() }))
    }

    private var rackFrom = 0f
    private var rackToP = 0f
    private var rackT0 = 0L
    private var rackDur = 1L
    private val rackRun = object : Runnable {
        override fun run() {
            val f = ((SystemClock.elapsedRealtime() - rackT0).toFloat() / rackDur).coerceIn(0f, 1f)
            focusP = rackFrom + (rackToP - rackFrom) * f
            refresh()
            if (f < 1f) ui.postDelayed(this, 40) else if (panelName == "FOCUS") rebuildPanel()
        }
    }

    private fun rack(i: Int) {
        if (minFocus <= 0f) { toast("Manual focus not supported"); return }
        manualFocus = true; afLock = false
        rackFrom = focusP; rackToP = marks[i]; rackT0 = SystemClock.elapsedRealtime(); rackDur = rackSec * 1000L
        ui.removeCallbacks(rackRun); ui.post(rackRun)
    }

    private fun panelExposure() {
        quick.addView(hrow(
            tb("AUTO", !manualExp) { setManualExp(false); rebuildPanel() }, tb("MANUAL", manualExp, manualOk) { setManualExp(true); rebuildPanel() },
            tb("AE LOCK", aeLock, !manualExp) { aeLock = !aeLock; refresh(); rebuildPanel() },
            tb("ZEBRA", analyzer.zebra) { analyzer.zebra = !analyzer.zebra; rebuildPanel() },
            tb("ZEBRA ${analyzer.zebraLevel}%") { analyzer.zebraLevel = if (analyzer.zebraLevel >= 100) 75 else analyzer.zebraLevel + 5; analyzer.zebra = true; rebuildPanel() },
            tb("FALSE COLOR", analyzer.falseColor) { analyzer.falseColor = !analyzer.falseColor; rebuildPanel() },
            tb("LOOK " + looks[lookIdx.coerceIn(0, looks.size - 1)], lookIdx != 0) { cycleLook(); rebuildPanel() }))
        quick.addView(sRow("EXPOSURE", if (evRange.upper > evRange.lower) (evIdx - evRange.lower) * 1000 / (evRange.upper - evRange.lower) else 500,
            { p -> String.format(Locale.US, "%+.1f EV", (evRange.lower + (evRange.upper - evRange.lower) * p / 1000.0) * evStep) }) { p ->
            if (manualExp) toast("EV applies in AUTO exposure") else { evIdx = (evRange.lower + (evRange.upper - evRange.lower) * p / 1000.0).roundToInt(); refresh() }
        })
    }

    private fun panelMonitor() {
        fun t(label: String, on: Boolean, f: () -> Unit) = tb(label, on) { f(); applyMonitors(); rebuildPanel() }
        quick.addView(hrow(
            t("HISTOGRAM", overlay.showHist) { overlay.showHist = !overlay.showHist }, t("AUDIO", overlay.showAudio) { overlay.showAudio = !overlay.showAudio },
            t("LEVEL", overlay.showLevel) { overlay.showLevel = !overlay.showLevel }, t("THIRDS", overlay.grid == 1) { overlay.grid = if (overlay.grid == 1) 0 else 1 },
            t("CROSSHAIR", overlay.cross) { overlay.cross = !overlay.cross }, t("CENTER DOT", overlay.dot) { overlay.dot = !overlay.dot }))
        quick.addView(hrow(
            t("PEAKING", analyzer.peak) { analyzer.peak = !analyzer.peak }, t("ZEBRA", analyzer.zebra) { analyzer.zebra = !analyzer.zebra },
            t("FALSE COLOR", analyzer.falseColor) { analyzer.falseColor = !analyzer.falseColor },
            t("GUIDE " + OverlayView.GUIDES[overlay.guideIdx], overlay.guideIdx != 0) { overlay.guideIdx = (overlay.guideIdx + 1) % OverlayView.GUIDES.size },
            t("DE-SQUEEZE ${sqVals[sqIdx]}×", sqIdx != 0) { sqIdx = (sqIdx + 1) % 4; setFrameAspect() },
            t("FLIP", flip) { flip = !flip; applyTransform() }))
    }

    private fun applyMonitors() { updateSensor(); overlay.invalidate() }

    private fun panelFps() {
        quick.addView(hrow(*fpsList.map { f -> tb("$f", f == fps) { setFps(f) } }.toTypedArray()))
        quick.addView(hrow(*listOf(1, 2, 5, 10, 30).map { f -> tb(if (f == 1) "OFF-SPEED: OFF" else "TIME-LAPSE ×$f", tl == f) { tl = f; rebuildPanel() } }.toTypedArray()))
        quick.addView(TextView(this).apply { text = "Time-lapse records without sound and plays back at the chosen frame rate."; setTextColor(0xFFAAAAAA.toInt()); textSize = 11f; setPadding(dp(12), 0, 0, dp(4)) })
    }

    private fun setFps(f: Int) {
        if (recording) return
        fps = f; expNs = snapFlicker(expNs)
        refresh(); hudUpdate(); rebuildPanel()
    }

    private fun panelRes() {
        quick.addView(hrow(*videoSizes.map { s -> tb(if (s.height >= 2160) "4K" else "${s.height}p", s.height == resH) { if (!recording) { resH = s.height; cam { closeCamera(); openCamera() } } } }.toTypedArray()))
        quick.addView(hrow(tb("H.264", !hevc) { hevc = false; rebuildPanel() }, tb("H.265", hevc, hevcOk) { hevc = true; rebuildPanel() },
            *listOf(10, 20, 40, 80, 120).map { m -> tb("${m}M", mbps == m) { mbps = m; rebuildPanel() } }.toTypedArray()))
    }

    private fun bestLensIdx(): Int {
        val eff = curFactor() * zoom
        var best = -1; var bd = Float.MAX_VALUE
        lensBtns.forEachIndexed { i, b -> val dd = abs(ln(eff / b.factor)); if (dd < bd) { bd = dd; best = i } }
        return best
    }

    private fun curFactor() = lenses.firstOrNull { it.id == camId }?.factor ?: 1f

    private fun panelLens() {
        val items = mutableListOf<View>(tb(if (facing == CameraCharacteristics.LENS_FACING_FRONT) "FRONT" else "REAR", true) { cam { switchCamera() } })
        val best = bestLensIdx()
        lensBtns.forEachIndexed { i, b -> items.add(tb(b.label + "×", i == best) { pickLens(b); rebuildPanel() }) }
        quick.addView(hrow(*items.toTypedArray()))
        if (zoomMax > zoomMin) quick.addView(sRow("ZOOM", lp(zoom.toDouble(), zoomMin.toDouble(), zoomMax.toDouble()),
            { p -> String.format(Locale.US, "%.1f×", unlp(p, zoomMin.toDouble(), zoomMax.toDouble())) }) { p ->
            zoom = unlp(p, zoomMin.toDouble(), zoomMax.toDouble()).toFloat(); refresh(); hudUpdate()
        })
    }

    // ───────────────────────── settings, slate, info ─────────────────────────
    private fun cycleLook() { lookIdx = (lookIdx + 1) % looks.size; refresh() }

    private fun typeName(t: Int) = when (t) {
        AudioDeviceInfo.TYPE_BUILTIN_MIC -> "built-in"; AudioDeviceInfo.TYPE_WIRED_HEADSET -> "wired headset"
        AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> "USB"; AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth"
        else -> "type $t"
    }

    private fun chooseMic() {
        val devs = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS).toList()
        val names = (listOf("Automatic") + devs.map { "${it.productName} (${typeName(it.type)})" }).toTypedArray()
        AlertDialog.Builder(this).setTitle("Microphone").setItems(names) { _, w -> micId = if (w == 0) -1 else devs[w - 1].id; savePrefs() }.show()
    }

    private fun showSettings() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(8)) }
        fun row(label: String, value: () -> String, tap: () -> Unit) {
            val b = Button(this)
            fun upd() { b.text = "$label:  ${value()}" }
            b.setOnClickListener { tap(); upd(); hudUpdate() }
            upd(); col.addView(b, LinearLayout.LayoutParams(-1, -2))
        }
        row("Codec", { if (hevc) "H.265 (HEVC)" else "H.264 (AVC)" }) { if (hevcOk) { hevc = !hevc } else { toast("No HEVC encoder on this device") } }
        row("Bitrate", { "$mbps Mbps" }) { mbps = when (mbps) { 10 -> 20; 20 -> 40; 40 -> 80; 80 -> 120; else -> 10 } }
        row("Microphone", { if (micId < 0) "Automatic" else "device #$micId" }) { chooseMic() }
        row("Mic direction", { listOf("Automatic", "Towards user (front)", "Away from user (rear)")[micDir] }) { micDir = (micDir + 1) % 3 }
        row("Audio channels", { if (micCh == 1) "Mono" else "Stereo" }) { micCh = if (micCh == 1) 2 else 1 }
        row("Storage", { if (safTree == null) "Phone (Movies/PHIRMS)" else "External folder" }) {
            if (safTree == null) { try { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 42) } catch (e: Exception) { toast("No file picker available") } }
            else { safTree = null; toast("Recording to the phone again") }
        }
        row("Digital slate", { "$slProject / R$slReel / S$slScene / T$slTake" }) { showSlate() }
        row("Volume keys record", { if (volKeys) "ON" else "OFF" }) { volKeys = !volKeys }
        row("Look / filter", { looks[lookIdx.coerceIn(0, looks.size - 1)] }) { cycleLook() }
        row("Stabilization", { stabOpts[stabIdx.coerceIn(0, stabOpts.size - 1)] }) { stabIdx = (stabIdx + 1) % stabOpts.size; refresh() }
        row("Photo quality", { "JPEG $jpegQ" }) { jpegQ = when (jpegQ) { 80 -> 90; 90 -> 95; else -> 80 } }
        row("Photo style", { if (portraitOn) "PORTRAIT BLUR" else "NORMAL" }) { portraitOn = !portraitOn }
        row("Portrait blur strength", { String.format(Locale.US, "ƒ %.1f", 16.0 * (1.4 / 16.0).pow(depthP.toDouble())) }) { depthP = if (depthP >= 0.95f) 0.2f else depthP + 0.2f }
        col.addView(Button(this).apply { text = "Phone camera list (lenses)"; setOnClickListener { showCamInfo() } }, LinearLayout.LayoutParams(-1, -2))
        col.addView(TextView(this).apply {
            text = "Videos: Movies/PHIRMS    Photos: Pictures/PHIRMS\nRecording uses AAC audio in MP4. Settings that a phone does not support are disabled or hidden."
            setPadding(dp(8), dp(12), dp(8), dp(4))
        })
        AlertDialog.Builder(this).setTitle("PHIRMS settings").setView(ScrollView(this).apply { addView(col) }).setPositiveButton("Close", null).show()
    }

    private fun showSlate() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        fun field(label: String, value: String, num: Boolean = false): EditText {
            col.addView(TextView(this).apply { text = label })
            val e = EditText(this).apply { setText(value); setSingleLine(); if (num) inputType = InputType.TYPE_CLASS_NUMBER }
            col.addView(e); return e
        }
        val fp = field("Project", slProject); val fr = field("Reel", slReel); val fs = field("Scene", slScene); val ft = field("Take", slTake.toString(), true)
        val good = CheckBox(this).apply { text = "Good take"; isChecked = slGood }
        val ext = CheckBox(this).apply { text = "Exterior (off = Interior)"; isChecked = slExt }
        val night = CheckBox(this).apply { text = "Night (off = Day)"; isChecked = slNight }
        col.addView(good); col.addView(ext); col.addView(night)
        AlertDialog.Builder(this).setTitle("Digital slate").setView(ScrollView(this).apply { addView(col) })
            .setPositiveButton("Save") { _, _ ->
                slProject = fp.text.toString().ifBlank { "PHIRMS" }; slReel = fr.text.toString().ifBlank { "1" }; slScene = fs.text.toString().ifBlank { "1" }
                slTake = ft.text.toString().toIntOrNull() ?: 1; slGood = good.isChecked; slExt = ext.isChecked; slNight = night.isChecked; savePrefs()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun slateName(): String {
        fun s(x: String) = x.replace(Regex("[^A-Za-z0-9_-]"), "_")
        return "${s(slProject)}_R${s(slReel)}_S${s(slScene)}_T${slTake}${if (slGood) "_GT" else ""}_${if (slExt) "EXT" else "INT"}_${if (slNight) "NIGHT" else "DAY"}_${stamp()}"
    }

    private fun focalEq(c: CameraCharacteristics): Float? {
        val f = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull() ?: return null
        val sz = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE) ?: return null
        return (f * 43.27 / hypot(sz.width.toDouble(), sz.height.toDouble())).toFloat()
    }

    private fun showCamInfo() {
        val sb = StringBuilder()
        try {
            for (id in cm.cameraIdList) {
                val c = cm.getCameraCharacteristics(id)
                val face = when (c.get(CameraCharacteristics.LENS_FACING)) { CameraCharacteristics.LENS_FACING_FRONT -> "front"; CameraCharacteristics.LENS_FACING_BACK -> "back"; else -> "ext" }
                val eq = focalEq(c)?.roundToInt()?.toString() ?: "?"
                val lvl = when (c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)) {
                    CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY -> "LEGACY"; CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED -> "LIMITED"
                    CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_FULL -> "FULL"; CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_3 -> "LEVEL_3"; else -> "?" }
                val zr = if (Build.VERSION.SDK_INT >= 30) c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)?.toString() ?: "-" else "n/a"
                val ap = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_APERTURES)?.joinToString(",") ?: "-"
                sb.append("ID $id  $face  ~${eq}mm  $lvl\n   physical=${c.physicalCameraIds}  zoom=$zr  aperture=$ap\n")
            }
        } catch (e: Exception) { sb.append("Error: ${e.message}") }
        sb.append("\nIf only one rear camera is listed, this phone hides its other lenses from third-party apps.")
        AlertDialog.Builder(this).setTitle("Phone cameras").setMessage(sb.toString()).setPositiveButton("Close", null).show()
    }

    // ───────────────────────── camera ─────────────────────────
    private val stateCb = object : CameraDevice.StateCallback() {
        override fun onOpened(c: CameraDevice) { unlock(); camera = c; cam { startPreview() } }
        override fun onDisconnected(c: CameraDevice) { unlock(); c.close(); camera = null }
        override fun onError(c: CameraDevice, e: Int) {
            unlock(); c.close(); camera = null; toast("Camera error $e")
            if (recording) cam { stopRecording(false) }
        }
    }

    private fun unlock() { if (lockHeld.getAndSet(false)) openLock.release() }

    private fun lensIds(): List<String> = cm.cameraIdList.filter {
        val c = cm.getCameraCharacteristics(it)
        c.get(CameraCharacteristics.LENS_FACING) == facing &&
            (c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE) ?: true)
    }

    private fun discoverLenses(ids: List<String>) {
        val eqs = ids.map { it to (focalEq(cm.getCameraCharacteristics(it)) ?: 26f) }
        val main = eqs.minByOrNull { abs(it.second - 26f) }?.second ?: 26f
        lenses = eqs.map { Lens(it.first, it.second / main) }.sortedBy { it.factor }
    }

    private fun zoomRatioLower(id: String): Float =
        if (Build.VERSION.SDK_INT >= 30) cm.getCameraCharacteristics(id).get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)?.lower ?: 1f else 1f

    private fun buildLensBtns() {
        val l = mutableListOf<LensBtn>()
        for (ln in lenses) { val f = ln.factor; l += LensBtn(if (f < 0.75f) "0.5" else if (f < 1.4f) "1" else "${f.roundToInt()}", ln.id, 1f, f) }
        if (facing == CameraCharacteristics.LENS_FACING_BACK) {
            val mainId = lenses.minByOrNull { abs(it.factor - 1f) }?.id
            if (mainId != null) {
                if (l.none { it.factor < 0.75f } && zoomRatioLower(mainId) <= 0.55f) l += LensBtn("0.5", mainId, 0.5f, 0.5f)
                if (l.none { it.factor >= 1.8f }) l += LensBtn("2", mainId, 2f, 2f)
            }
        }
        lensBtns = l.sortedBy { it.factor }
    }

    private fun pickLens(b: LensBtn) {
        if (b.id == camId) { zoom = b.zoom.coerceIn(zoomMin, zoomMax); refresh(); return }
        if (recording) { toast("Stop recording to change lens"); return }
        lensId = b.id; zoom = b.zoom
        cam { closeCamera(); openCamera() }
    }

    @Suppress("MissingPermission")
    private fun openCamera() {
        if (camera != null || !hasPerm(Manifest.permission.CAMERA) || !tv.isAvailable) return
        if (!openLock.tryAcquire(2500, TimeUnit.MILLISECONDS)) { toast("Camera busy"); return }
        lockHeld.set(true)
        try {
            val ids = lensIds()
            if (ids.isEmpty()) { unlock(); toast("No camera found"); return }
            discoverLenses(ids)
            val id = if (lensId != null && lensId in ids) lensId!! else (lenses.minByOrNull { abs(it.factor - 1f) }?.id ?: ids[0])
            lensId = id; camId = id
            chars = cm.getCameraCharacteristics(id)
            calOk = false; calDay = null; calInc = null; calBusy = false; calMode = null; regions = null; afLock = false; aeLock = false
            configure()
            buildLensBtns()
            runOnUiThread { applyTransform(); hudUpdate(); if (panelName != null) rebuildPanel() }
            cm.openCamera(id, stateCb, bg)
        } catch (e: Exception) { unlock(); Log.e(tag, "open", e); toast("Open failed: ${e.message}") }
    }

    private fun closeCamera() {
        val got = openLock.tryAcquire(2500, TimeUnit.MILLISECONDS)
        if (got) lockHeld.set(true)
        try {
            session?.close(); session = null
            camera?.close(); camera = null
            jpegReader?.close(); jpegReader = null
            builder = null
        } finally { unlock() }
    }

    private fun switchCamera() {
        if (recording) return
        facing = if (facing == CameraCharacteristics.LENS_FACING_BACK) CameraCharacteristics.LENS_FACING_FRONT else CameraCharacteristics.LENS_FACING_BACK
        lensId = null; zoom = 1f
        closeCamera(); openCamera()
    }

    private fun encoderExists(mime: String) = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
        .any { it.isEncoder && it.supportedTypes.any { t -> t.equals(mime, true) } }

    private fun clampBitrate(bps: Int, mime: String): Int = try {
        MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
            .firstOrNull { it.isEncoder && it.supportedTypes.any { t -> t.equals(mime, true) } }
            ?.getCapabilitiesForType(mime)?.videoCapabilities?.bitrateRange?.clamp(bps) ?: bps
    } catch (e: Exception) { bps }

    /** Reads real hardware capabilities; nothing is assumed. */
    private fun configure() {
        val ch = chars!!
        val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val all = (map.getOutputSizes(MediaRecorder::class.java) ?: emptyArray()).toList()
        var v = all.filter { it.width * 9 == it.height * 16 && it.height in 720..2160 }.sortedBy { it.height }
        if (v.isEmpty()) v = all.filter { it.height in 480..2160 }.sortedBy { it.width * it.height }
        if (v.isEmpty()) v = listOf(all.maxByOrNull { it.width * it.height } ?: Size(1280, 720))
        videoSizes = v
        videoSize = v.firstOrNull { it.height == resH } ?: v.minByOrNull { abs(it.height - resH) }!!
        resH = videoSize.height
        val prev = (map.getOutputSizes(SurfaceTexture::class.java) ?: emptyArray()).filter { it.width <= 1920 }
        val jp = (map.getOutputSizes(ImageFormat.JPEG) ?: emptyArray()).toList()
        fun same(s: Size) = s.width * videoSize.height == s.height * videoSize.width
        previewSize = prev.filter { same(it) }.maxByOrNull { it.width * it.height } ?: prev.maxByOrNull { it.width * it.height } ?: Size(1280, 720)
        photoSize = jp.filter { same(it) }.maxByOrNull { it.width * it.height } ?: jp.maxByOrNull { it.width * it.height } ?: previewSize

        val ranges = ch.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
        val minDur = map.getOutputMinFrameDuration(MediaRecorder::class.java, videoSize)
        fpsList = listOf(24, 25, 30, 50, 60).filter { f ->
            (ranges?.any { it.lower <= f && it.upper >= f } ?: (f <= 30)) && (minDur <= 0 || 1e9 / minDur >= f - 0.5)
        }.ifEmpty { listOf(30) }
        if (fps !in fpsList) fps = if (30 in fpsList) 30 else fpsList.last()

        manualOk = ch.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR) == true
        val post = ch.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_POST_PROCESSING) == true
        awbAvail = ch.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES)?.toList() ?: listOf(CameraMetadata.CONTROL_AWB_MODE_AUTO)
        wbManualOk = post && CameraMetadata.CONTROL_AWB_MODE_OFF in awbAvail && CameraMetadata.CONTROL_AWB_MODE_DAYLIGHT in awbAvail &&
            CameraMetadata.CONTROL_AWB_MODE_INCANDESCENT in awbAvail
        if (!wbManualOk && wbKind == 2) wbKind = 0
        isoRange = ch.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE) ?: Range(100, 100)
        expRange = ch.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE) ?: Range(1_000_000L, 1_000_000L)
        minFocus = ch.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        evRange = ch.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE) ?: Range(0, 0)
        evStep = ch.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: 0f
        apertures = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_APERTURES) ?: floatArrayOf()
        apIdx = apIdx.coerceIn(0, max(0, apertures.size - 1))
        val zr = if (Build.VERSION.SDK_INT >= 30) ch.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE) else null
        useRatio = zr != null
        zoomMin = zr?.lower ?: 1f
        zoomMax = min(10f, zr?.upper ?: (ch.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM) ?: 1f))
        maxAf = ch.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF) ?: 0
        maxAe = ch.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE) ?: 0
        if (!manualOk) manualExp = false
        if (minFocus <= 0f) manualFocus = false
        iso = iso.coerceIn(isoRange.lower, isoRange.upper)
        expNs = expNs.coerceIn(shutMin(), shutMax())
        evIdx = evIdx.coerceIn(evRange.lower, evRange.upper)
        zoom = zoom.coerceIn(zoomMin, zoomMax)
        wbPreset = wbPreset.coerceIn(0, 4)

        val st = mutableListOf("OFF")
        if (ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)?.contains(CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON) == true) st += "OIS"
        if (ch.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)?.contains(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON) == true) st += "EIS"
        stabOpts = st; stabIdx = stabIdx.coerceIn(0, st.size - 1)

        val l = mutableListOf("OFF")
        val tm = ch.get(CameraCharacteristics.TONEMAP_AVAILABLE_TONE_MAP_MODES)?.toList() ?: emptyList()
        if (CameraMetadata.TONEMAP_MODE_CONTRAST_CURVE in tm && (ch.get(CameraCharacteristics.TONEMAP_MAX_CURVE_POINTS) ?: 0) >= 5)
            l += listOf("CONTRAST", "TEAL-ORANGE", "WARM", "COOL", "FADED")
        val fx = ch.get(CameraCharacteristics.CONTROL_AVAILABLE_EFFECTS)?.toList() ?: emptyList()
        if (CameraMetadata.CONTROL_EFFECT_MODE_MONO in fx) l += "B&W"
        if (CameraMetadata.CONTROL_EFFECT_MODE_SEPIA in fx) l += "SEPIA"
        if (CameraMetadata.CONTROL_EFFECT_MODE_NEGATIVE in fx) l += "NEGATIVE"
        looks = l; lookIdx = lookIdx.coerceIn(0, l.size - 1)
        if (hevc && !hevcOk) hevc = false
    }

    /** Screen rotation relative to sensor; also used for JPEG and video orientation. */
    private fun rel(): Int {
        val sens = chars?.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
        val disp = when (rotation()) { Surface.ROTATION_90 -> 90; Surface.ROTATION_180 -> 180; Surface.ROTATION_270 -> 270; else -> 0 }
        return if (facing == CameraCharacteristics.LENS_FACING_FRONT) (sens + disp) % 360 else (sens - disp + 360) % 360
    }

    private fun cropRect(): Rect {
        val a = chars!!.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)!!
        val z = max(zoom, 1f)
        val w = (a.width() / z).toInt(); val h = (a.height() / z).toInt()
        return Rect(a.centerX() - w / 2, a.centerY() - h / 2, a.centerX() + w / 2, a.centerY() + h / 2)
    }

    private fun lookCurve(n: String): TonemapCurve? {
        fun c(r: FloatArray, g: FloatArray = r, b: FloatArray = r) = TonemapCurve(r, g, b)
        return when (n) {
            "CONTRAST" -> c(floatArrayOf(0f, 0f, 0.25f, 0.18f, 0.5f, 0.5f, 0.75f, 0.82f, 1f, 1f))
            "TEAL-ORANGE" -> c(
                floatArrayOf(0f, 0f, 0.25f, 0.20f, 0.5f, 0.52f, 0.75f, 0.85f, 1f, 1f),
                floatArrayOf(0f, 0f, 0.25f, 0.25f, 0.5f, 0.50f, 0.75f, 0.74f, 1f, 1f),
                floatArrayOf(0f, 0f, 0.25f, 0.31f, 0.5f, 0.48f, 0.75f, 0.68f, 1f, 1f))
            "WARM" -> c(
                floatArrayOf(0f, 0f, 0.25f, 0.28f, 0.5f, 0.55f, 0.75f, 0.80f, 1f, 1f),
                floatArrayOf(0f, 0f, 0.25f, 0.25f, 0.5f, 0.50f, 0.75f, 0.75f, 1f, 1f),
                floatArrayOf(0f, 0f, 0.25f, 0.22f, 0.5f, 0.45f, 0.75f, 0.70f, 1f, 1f))
            "COOL" -> c(
                floatArrayOf(0f, 0f, 0.25f, 0.22f, 0.5f, 0.45f, 0.75f, 0.70f, 1f, 1f),
                floatArrayOf(0f, 0f, 0.25f, 0.25f, 0.5f, 0.50f, 0.75f, 0.75f, 1f, 1f),
                floatArrayOf(0f, 0f, 0.25f, 0.28f, 0.5f, 0.55f, 0.75f, 0.80f, 1f, 1f))
            "FADED" -> c(floatArrayOf(0f, 0.08f, 0.25f, 0.28f, 0.5f, 0.52f, 0.75f, 0.76f, 1f, 0.95f))
            else -> null
        }
    }

    /** Approximate manual white balance from two calibration points (daylight/incandescent presets) in mired space. */
    private fun kelvinGains(): RggbChannelVector? {
        val d = calDay ?: return null
        val i = calInc ?: return null
        val m = 1e6f / kelvin
        val t = ((m - 1e6f / 5500f) / (1e6f / 2850f - 1e6f / 5500f)).coerceIn(-0.6f, 1.5f)
        fun l(k: Int) = d[k] + (i[k] - d[k]) * t
        val tf = 1f - 0.003f * tint
        return RggbChannelVector(l(0), l(1) * tf, l(2) * tf, l(3))
    }

    private fun calibrateWb() {
        if (calBusy || calOk || !wbManualOk || session == null) return
        calBusy = true
        toast("Calibrating white balance…")
        calMode = CameraMetadata.CONTROL_AWB_MODE_DAYLIGHT
        refresh()
        bg?.postDelayed({
            lastGains?.let { calDay = floatArrayOf(it.red, it.greenEven, it.greenOdd, it.blue) }
            calTransform = lastTransform
            calMode = CameraMetadata.CONTROL_AWB_MODE_INCANDESCENT
            applyNowSafe()
            bg?.postDelayed({
                lastGains?.let { calInc = floatArrayOf(it.red, it.greenEven, it.greenOdd, it.blue) }
                calMode = null
                val d = calDay; val i = calInc
                calOk = d != null && i != null && calTransform != null && abs(d[0] - i[0]) + abs(d[3] - i[3]) > 0.05f
                if (!calOk) { wbManualOk = false; wbKind = 0; toast("This camera does not report colour gains – use the WB presets") }
                calBusy = false
                applyNowSafe()
                runOnUiThread { hudUpdate(); if (panelName == "WB") rebuildPanel() }
            }, 900)
        }, 900)
    }

    private fun applyNowSafe() { try { applyNow() } catch (e: Exception) { Log.e(tag, "apply", e) } }

    private fun applyControls(b: CaptureRequest.Builder, record: Boolean) {
        val ch = chars ?: return
        b.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
        if (useRatio && Build.VERSION.SDK_INT >= 30) b.set(CaptureRequest.CONTROL_ZOOM_RATIO, zoom.coerceIn(zoomMin, zoomMax))
        else b.set(CaptureRequest.SCALER_CROP_REGION, cropRect())
        val fr = ch.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.filter { it.lower <= fps && it.upper >= fps }
            ?.minByOrNull { it.upper - it.lower }
        if (manualExp) {
            b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF)
            b.set(CaptureRequest.SENSOR_SENSITIVITY, iso)
            b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, expNs.coerceIn(shutMin(), shutMax()))
            b.set(CaptureRequest.SENSOR_FRAME_DURATION, frameNs)
            if (apertures.size > 1) b.set(CaptureRequest.LENS_APERTURE, apertures[apIdx.coerceIn(0, apertures.size - 1)])
        } else {
            b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON)
            b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, evIdx)
            if (aeLock) b.set(CaptureRequest.CONTROL_AE_LOCK, true)
            if (fr != null) b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, fr)
        }
        if (manualFocus && minFocus > 0f) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_OFF)
            b.set(CaptureRequest.LENS_FOCUS_DISTANCE, focusP * minFocus)
        } else if (afLock) b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_AUTO)
        else b.set(CaptureRequest.CONTROL_AF_MODE, if (record) CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO else CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
        val kind = if (wbKind == 2 && !(calOk && wbManualOk)) 0 else wbKind
        when (kind) {
            1 -> b.set(CaptureRequest.CONTROL_AWB_MODE, wbModesAll[wbPreset.coerceIn(0, 4)].let { if (it in awbAvail) it else CameraMetadata.CONTROL_AWB_MODE_AUTO })
            2 -> {
                b.set(CaptureRequest.CONTROL_AWB_MODE, CameraMetadata.CONTROL_AWB_MODE_OFF)
                b.set(CaptureRequest.COLOR_CORRECTION_MODE, CameraMetadata.COLOR_CORRECTION_MODE_TRANSFORM_MATRIX)
                kelvinGains()?.let { b.set(CaptureRequest.COLOR_CORRECTION_GAINS, it) }
                calTransform?.let { b.set(CaptureRequest.COLOR_CORRECTION_TRANSFORM, it) }
            }
            else -> b.set(CaptureRequest.CONTROL_AWB_MODE, CameraMetadata.CONTROL_AWB_MODE_AUTO)
        }
        calMode?.let { b.set(CaptureRequest.CONTROL_AWB_MODE, it); b.set(CaptureRequest.COLOR_CORRECTION_MODE, CameraMetadata.COLOR_CORRECTION_MODE_FAST) }
        val stab = stabOpts[stabIdx.coerceIn(0, stabOpts.size - 1)]
        if ("OIS" in stabOpts) b.set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE, if (stab == "OIS") 1 else 0)
        if ("EIS" in stabOpts) b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, if (stab == "EIS" && record) 1 else 0)
        val look = looks[lookIdx.coerceIn(0, looks.size - 1)]
        b.set(CaptureRequest.CONTROL_EFFECT_MODE, when (look) {
            "B&W" -> CameraMetadata.CONTROL_EFFECT_MODE_MONO; "SEPIA" -> CameraMetadata.CONTROL_EFFECT_MODE_SEPIA
            "NEGATIVE" -> CameraMetadata.CONTROL_EFFECT_MODE_NEGATIVE; else -> CameraMetadata.CONTROL_EFFECT_MODE_OFF
        })
        lookCurve(look)?.let { b.set(CaptureRequest.TONEMAP_MODE, CameraMetadata.TONEMAP_MODE_CONTRAST_CURVE); b.set(CaptureRequest.TONEMAP_CURVE, it) }
        regions?.let {
            if (maxAf > 0) b.set(CaptureRequest.CONTROL_AF_REGIONS, it)
            if (maxAe > 0 && !manualExp) b.set(CaptureRequest.CONTROL_AE_REGIONS, it)
        }
    }

    private fun applyNow() {
        val b = builder ?: return
        val s = session ?: return
        applyControls(b, recording)
        s.setRepeatingRequest(b.build(), captureCb, bg)
    }

    private fun refresh() = cam { applyNow() }

    private val captureCb = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(s: CameraCaptureSession, r: CaptureRequest, res: TotalCaptureResult) {
            res.get(CaptureResult.COLOR_CORRECTION_GAINS)?.let { lastGains = it }
            res.get(CaptureResult.COLOR_CORRECTION_TRANSFORM)?.let { lastTransform = it }
            lastIso = res.get(CaptureResult.SENSOR_SENSITIVITY)
            lastExp = res.get(CaptureResult.SENSOR_EXPOSURE_TIME)
            lastAperture = res.get(CaptureResult.LENS_APERTURE)
        }
    }

    @Suppress("DEPRECATION")
    private fun startPreview() {
        val c = camera ?: return
        val st = tv.surfaceTexture ?: return
        session?.close(); session = null
        st.setDefaultBufferSize(previewSize.width, previewSize.height)
        val ps = Surface(st)
        jpegReader?.close()
        val jr = ImageReader.newInstance(photoSize.width, photoSize.height, ImageFormat.JPEG, 2)
        jr.setOnImageAvailableListener({ savePhoto(it) }, bg)
        jpegReader = jr
        c.createCaptureSession(listOf(ps, jr.surface), object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(s: CameraCaptureSession) {
                if (camera == null) return
                session = s
                val b = c.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                b.addTarget(ps); builder = b
                applyControls(b, false)
                try { s.setRepeatingRequest(b.build(), captureCb, bg) } catch (e: Exception) { Log.e(tag, "preview", e) }
            }
            override fun onConfigureFailed(s: CameraCaptureSession) { toast("Preview configuration failed") }
        }, bg)
    }

    private fun tapFocus(nx0: Float, ny0: Float) {
        overlay.tapX = nx0; overlay.tapY = ny0; overlay.tapAt = System.currentTimeMillis()
        afLock = false; aeLock = false
        cam {
            val ch = chars ?: return@cam
            val crop = cropRect()
            val (nx, ny) = when (rel()) {
                90 -> ny0 to (1 - nx0)
                180 -> (1 - nx0) to (1 - ny0)
                270 -> (1 - ny0) to nx0
                else -> nx0 to ny0
            }
            val half = (min(crop.width(), crop.height()) * 0.07f).toInt()
            val cx = crop.left + (nx * crop.width()).toInt(); val cy = crop.top + (ny * crop.height()).toInt()
            val a = ch.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)!!
            val x = (cx - half).coerceIn(a.left, a.right - 2 * half - 1); val y = (cy - half).coerceIn(a.top, a.bottom - 2 * half - 1)
            regions = arrayOf(MeteringRectangle(x, y, 2 * half, 2 * half, 1000))
            val b = builder ?: return@cam
            val s = session ?: return@cam
            applyControls(b, recording)
            if (!manualFocus && maxAf > 0) {
                b.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_CANCEL); s.capture(b.build(), null, bg)
                b.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_START); s.capture(b.build(), null, bg)
                b.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_IDLE)
            }
            s.setRepeatingRequest(b.build(), captureCb, bg)
        }
    }

    // ───────────────────────── photo ─────────────────────────
    private fun takePhoto() = cam {
        if (recording) { toast("Stop recording to take a photo"); return@cam }
        val c = camera ?: return@cam
        val jr = jpegReader ?: return@cam
        val s = session ?: return@cam
        pendingPortrait = portraitOn
        val b = c.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
        b.addTarget(jr.surface)
        applyControls(b, false)
        b.set(CaptureRequest.JPEG_ORIENTATION, rel())
        b.set(CaptureRequest.JPEG_QUALITY, jpegQ.toByte())
        s.capture(b.build(), null, bg)
    }

    private fun savePhoto(r: ImageReader) {
        val img = r.acquireNextImage() ?: return
        val portrait = pendingPortrait
        val bytes = try {
            val buf = img.planes[0].buffer
            val arr = ByteArray(buf.remaining()); buf.get(arr); arr
        } finally { img.close() }
        if (portrait) {
            toast("Applying depth blur…")
            Portrait.process(bytes, depthP) { out, person ->
                if (out == null) { toast("Blur failed – saved normal photo"); writeJpeg(bytes, "PHIRMS") }
                else { writeJpeg(out, "PHIRMS_PORTRAIT"); if (!person) toast("No person found – used centre focus") }
            }
        } else writeJpeg(bytes, "PHIRMS")
    }

    private fun writeJpeg(bytes: ByteArray, prefix: String) {
        try {
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "${prefix}_${stamp()}.jpg")
                put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/PHIRMS")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)!!
            contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
            contentResolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            lastUri = uri; lastMime = "image/jpeg"
            toast("Photo saved to Pictures/PHIRMS")
        } catch (e: Exception) { Log.e(tag, "photo", e); toast("Photo save failed: ${e.message}") }
    }

    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    // ───────────────────────── video ─────────────────────────
    private fun onRecord() = cam { if (recording) stopRecording() else startRecording() }

    @Suppress("DEPRECATION")
    private fun startRecording() {
        val c = camera ?: return
        if (recording) return
        if (safTree == null && freeBytes() < 500L * 1024 * 1024) { toast("Need at least 500 MB free storage"); return }
        try {
            audioMeter.stop()
            val audio = hasPerm(Manifest.permission.RECORD_AUDIO) && tl <= 1
            if (!hasPerm(Manifest.permission.RECORD_AUDIO)) toast("No microphone permission – recording video only")
            val rec = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            recorder = rec
            val base = slateName()
            val uri: Uri
            if (safTree != null) {
                val tree = Uri.parse(safTree)
                val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
                uri = DocumentsContract.createDocument(contentResolver, parent, "video/mp4", base) ?: throw IllegalStateException("cannot create a file in the chosen folder")
                recIsSaf = true
            } else {
                val cv = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, "$base.mp4")
                    put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/PHIRMS")
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                    put(MediaStore.Video.VideoColumns.DESCRIPTION, "Project $slProject  Reel $slReel  Scene $slScene  Take $slTake${if (slGood) "  GOOD TAKE" else ""}")
                }
                uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!
                recIsSaf = false
            }
            recUri = uri
            recPfd = contentResolver.openFileDescriptor(uri, "w")
            if (audio) {
                rec.setAudioSource(MediaRecorder.AudioSource.MIC)
                if (micId >= 0) audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS).firstOrNull { it.id == micId }?.let { rec.setPreferredDevice(it) }
                if (micDir != 0) rec.setPreferredMicrophoneDirection(micDir)
            }
            rec.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setOutputFile(recPfd!!.fileDescriptor)
            val mime = if (hevc) "video/hevc" else "video/avc"
            rec.setVideoEncodingBitRate(clampBitrate(mbps * 1_000_000, mime))
            rec.setVideoFrameRate(fps)
            if (tl > 1) rec.setCaptureRate(fps.toDouble() / tl)
            rec.setVideoSize(videoSize.width, videoSize.height)
            rec.setVideoEncoder(if (hevc) MediaRecorder.VideoEncoder.HEVC else MediaRecorder.VideoEncoder.H264)
            if (audio) {
                rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC); rec.setAudioEncodingBitRate(if (micCh == 2) 256_000 else 128_000)
                rec.setAudioSamplingRate(48_000); rec.setAudioChannels(micCh)
            }
            rec.setOrientationHint(rel())
            rec.setOnErrorListener { _, _, _ -> cam { stopRecording() } }
            rec.setOnInfoListener { _, what, _ -> if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_FILESIZE_REACHED) cam { stopRecording() } }
            rec.prepare()

            val st = tv.surfaceTexture ?: throw IllegalStateException("no preview surface")
            st.setDefaultBufferSize(previewSize.width, previewSize.height)
            val ps = Surface(st)
            val rs = rec.surface
            val b = c.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
            b.addTarget(ps); b.addTarget(rs)
            applyControls(b, true)
            session?.close(); session = null
            c.createCaptureSession(listOf(ps, rs), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    try {
                        session = s; builder = b
                        s.setRepeatingRequest(b.build(), captureCb, bg)
                        rec.start()
                        recStart = SystemClock.elapsedRealtime()
                        recording = true
                        runOnUiThread { setRecUi(true) }
                    } catch (e: Exception) { Log.e(tag, "rec start", e); toast("Recording failed: ${e.message}"); stopRecording() }
                }
                override fun onConfigureFailed(s: CameraCaptureSession) { toast("Recording not supported with these settings"); stopRecording() }
            }, bg)
        } catch (e: Exception) {
            Log.e(tag, "prepare", e); toast("Cannot start recording: ${e.message}"); stopRecording()
        }
    }

    private fun stopRecording(restart: Boolean = true) {
        if (!recording && recorder == null) return
        var ok = recording
        recording = false
        try { session?.stopRepeating(); session?.abortCaptures() } catch (e: Exception) {}
        recorder?.let { r ->
            try { r.stop() } catch (e: RuntimeException) { ok = false; Log.e(tag, "stop", e) }
            try { r.reset() } catch (e: Exception) {}
            r.release()
        }
        recorder = null
        try { recPfd?.close() } catch (e: Exception) {}
        recPfd = null
        recUri?.let { u ->
            if (ok) {
                if (!recIsSaf) contentResolver.update(u, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
                lastUri = u; lastMime = "video/mp4"
                slTake += 1; slGood = false
                toast(if (recIsSaf) "Video saved to the chosen folder" else "Video saved to Movies/PHIRMS")
            } else {
                try { if (recIsSaf) DocumentsContract.deleteDocument(contentResolver, u) else contentResolver.delete(u, null, null) } catch (e: Exception) {}
            }
        }
        recUri = null
        runOnUiThread { setRecUi(false) }
        if (restart) {
            if (hasPerm(Manifest.permission.RECORD_AUDIO)) audioMeter.start()
            startPreview()
        }
    }
}
